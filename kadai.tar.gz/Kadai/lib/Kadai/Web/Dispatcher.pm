package Kadai::Web::Dispatcher;
use strict;
use warnings;
use utf8;
use Amon2::Web::Dispatcher::Lite;

any '/' => sub {
    my ($c) = @_;
    my @times = (0 .. 23);
    my $t_input = 0;
    my $t_start = 0;
    my $t_end = 0;
    my $result = '';

    if(my @params = $c->req->param) {
	$t_input = $c->req->param('t_input');
	$t_start = $c->req->param('t_start');
	$t_end = $c->req->param('t_end');

	if( $t_start < $t_end ) {
		if( $t_input >= $t_start && $t_input < $t_end ) {
			$result = 'はい、含まれます。';
		} else {
			$result = 'いいえ、含まれません。';
		}
	}

	if( $t_start > $t_end ) {
                if( ($t_input >= $t_start && $t_input < 24) || ($t_input >= 0 && $t_input < $t_end) ) {
                        $result = 'はい、含まれます。';
                } else {
                        $result = 'いいえ、含まれません。';
                }
        }

	if( $t_start == $t_end ) {
                if( $t_input == $t_start ) {
                        $result = 'はい、含まれます。';
                } else {
                        $result = 'いいえ、含まれません。';
                }
        }
    }

    return $c->render('kadai.tx' => {times => \@times, t_input => $t_input, t_start => $t_start, t_end => $t_end, result => $result} );
};

1;
